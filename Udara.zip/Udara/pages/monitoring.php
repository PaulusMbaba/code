<?php
include 'functions.php';
// mengambil nilai form
if(isset($_POST['submit'])){
  if(!is_numeric($_POST['co']) || !is_numeric($_POST['co2']) || !is_numeric($_POST['hc'])){
    $error = "Data CO, CO2, dan HC harus berupa angka!";
  }else{
    $hasil = [
      "tgl" => $_POST["tanggal"],
      "waktu" => $_POST['waktu'],
      "co" => $_POST['co'],
      "co2" => $_POST['co2'],
      "hc" => $_POST['hc'],
    ];
    $databaru = [
      "co" => (float)$_POST['co'],
      "co2" => (float)$_POST['co2'],
      "hc" => (float)$_POST['hc']
    ];
    $predicts = predict($databaru);
    $gauss = $predicts[0];
    $prob = $predicts[1];
    // print_r($predicts);die;
    $hasil['kelas'] = $predicts[2];
    create($hasil);
  }
}

?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- general form elements -->
        <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Input Data Klasifikasi</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="" method="post">
              <div class="card-body" style="width: 100%;">
                <div style="display: flex; width: 100%; justify-content: space-between;">
                    <div class="form-group" style="width: 40%;">
                      <label for="exampleSelectBorder">Waktu</code></label>
                      <select class="custom-select form-control-border" id="exampleSelectBorder" name="waktu">
                        <option value=""></option>
                        <option value="pagi">Pagi</option>
                        <option value="siang">Siang</option>
                        <option value="sore">Sore</option>
                      </select>
                    </div>
                    <div class="form-group" style="width: 40%;">
                      <label for="exampleInputPassword1">Tanggal</label>
                      <input type="date" class="form-control" id="exampleInputPassword1" placeholder="tanggal mengambil data (dd-mm-yyyy)" name="tanggal">
                    </div>
                </div>
                <div style="display: flex; width: 100%; justify-content: space-between;">
                    <div class="form-group" style="width: 30%">
                        <label for="exampleInputPassword1">CO</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai CO (ppm)" name="co">
                    </div>
                    <div class="form-group" style="width: 30%">
                        <label for="exampleInputPassword1">CO2</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai CO2 (ppm)" name="co2">
                    </div>
                    <div class="form-group" style="width: 30%">
                        <label for="exampleInputPassword1">HC</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai HC (ppm)" name="hc">
                    </div>
                </div>
              </div>
              <!-- /.card-body -->

              <div class="card-footer">
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.card -->

          <!-- general form elements -->
          <?php if(isset($hasil)):?>
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Klasifikasi Data Monitoring</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                        <th></th>
                        <th>CO</th>
                        <th>CO2</th>
                        <th>HC</th>
                        <th rowspan="2">Probabilitas</th>
                        <th>Kategori</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td></td>
                      <td class="bg-secondary"><?=$hasil["co"]?></td>
                      <td class="bg-secondary"><?=$hasil["co2"]?></td>
                      <td class="bg-secondary"><?=$hasil["hc"]?></td>
                      <td></td>
                      <td rowspan="4"><?=$hasil['kelas']?></td>
                    </tr>
                    <tr>
                      <td>Baik</td>
                      <td><?=$gauss['Baik'][0]?></td>
                      <td><?=$gauss['Baik'][1]?></td>
                      <td><?=$gauss['Baik'][2]?></td>
                      <td><?=$prob['Baik']?></td>
                    </tr>
                    <tr>
                      <td>Sedang</td>
                      <td><?=$gauss['Sedang'][0]?></td>
                      <td><?=$gauss['Sedang'][1]?></td>
                      <td><?=$gauss['Sedang'][2]?></td>
                      <td><?=$prob['Sedang']?></td>
                    </tr>
                    <tr>
                      <td>Tidak sehat</td>
                      <td><?=$gauss['Tidak sehat'][0]?></td>
                      <td><?=$gauss['Tidak sehat'][1]?></td>
                      <td><?=$gauss['Tidak sehat'][2]?></td>
                      <td><?=$prob['Tidak sehat']?></td>
                    </tr>

                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <?php endif;?>
            <?php if(isset($error)):?>
            <div class="card">
              <div class="card-body">
                <p><?=$error?></p>
              </div>
            </div>
            <?php endif;?>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- footer -->
<?php include './components/footer.php';?>
