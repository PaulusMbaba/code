<?php
    include 'functions.php';
    $dataPengujian = pengujian();
    $datauji = $dataPengujian[0];
    $prediksi = $dataPengujian[3];
?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>
<!-- main content -->
<div class="content-wrapper">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Hasil</h1>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- <div class="card-header">
                <h3 class="card-title">DataTable with minimal features & hover style</h3>
              </div> -->
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>CO</th>
                    <th>CO2</th>
                    <th>HC</th>
                    <th>Kelas</th>
                    <th>Prediksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php for($row = 0; $row < count($datauji); $row++):?>
                    <tr>
                      <td><?=$row+1?></td>
                      <td><?=$datauji[$row]["co"]?></td>
                      <td><?=$datauji[$row]["co2"]?></td>
                      <td><?=$datauji[$row]["hc"]?></td>
                      <td><?=$datauji[$row]["kelas"]?></td>
                      <td><?=$prediksi[$row]?></td>
                    </tr>
                  <?php endfor;?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /main content -->
<!-- footer -->
<?php include './components/footer.php';?>