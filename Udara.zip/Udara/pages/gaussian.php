<?php
    include 'functions.php';
    $dataPengujian = pengujian();
    $datauji = $dataPengujian[0];
    $gaussians = $dataPengujian[1];
    $probabilitas = $dataPengujian[2];

?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>
<!-- main content -->
<div class="content-wrapper">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Nilai Gaussian</h1>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- <div class="card-header">
                <h3 class="card-title">DataTable with minimal features & hover style</h3>
              </div> -->
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                        <th>No</th>
                        <th></th>
                        <th>CO</th>
                        <th>CO2</th>
                        <th>HC</th>
                        <th rowspan="2">Probabilitas</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php for($row = 0; $row < count($datauji); $row++):?>
                    <tr>
                      <td rowspan="4"><?=$row+1?></td>
                      <td></td>
                      <td class="bg-secondary"><?=$datauji[$row]["co"]?></td>
                      <td class="bg-secondary"><?=$datauji[$row]["co2"]?></td>
                      <td class="bg-secondary"><?=$datauji[$row]["hc"]?></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>Baik</td>
                      <td><?=$gaussians[$row]['Baik'][0]?></td>
                      <td><?=$gaussians[$row]['Baik'][1]?></td>
                      <td><?=$gaussians[$row]['Baik'][2]?></td>
                      <td><?=$probabilitas[$row]['Baik']?></td>
                    </tr>
                    <tr>
                      <td>Sedang</td>
                      <td><?=$gaussians[$row]['Sedang'][0]?></td>
                      <td><?=$gaussians[$row]['Sedang'][1]?></td>
                      <td><?=$gaussians[$row]['Sedang'][2]?></td>
                      <td><?=$probabilitas[$row]['Sedang']?></td>
                    </tr>
                    <tr>
                      <td>Tidak sehat</td>
                      <td><?=$gaussians[$row]['Tidak sehat'][0]?></td>
                      <td><?=$gaussians[$row]['Tidak sehat'][1]?></td>
                      <td><?=$gaussians[$row]['Tidak sehat'][2]?></td>
                      <td><?=$probabilitas[$row]['Tidak sehat']?></td>
                    </tr>

                  <?php endfor;?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /main content -->
<!-- footer -->
<?php include './components/footer.php';?>