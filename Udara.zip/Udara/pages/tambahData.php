<?php
include 'database.php';
// mengambil nilai form
if(isset($_POST['submit'])){
  $dataInsert = [
    "co" => $_POST['co'],
    "co2" => $_POST['co2'],
    "hc" => $_POST['hc'],
    "kelas" => $_POST['kelas']
  ];
  addDataset($dataInsert);
}

?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- general form elements -->
        <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Input Dataset</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="" method="post">
              <div class="card-body" style="width: 100%;">
                <div style="display: flex; width: 100%; justify-content: space-between;">
                    <div class="form-group">
                        <label for="exampleInputPassword1">CO</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai CO (ppm)" name="co">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">CO2</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai CO2 (ppm)" name="co2">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">HC</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="nilai HC (ppm)" name="hc">
                    </div>
                    <div class="form-group">
                      <label for="exampleSelectBorder">Kelas</code></label>
                      <select class="custom-select form-control-border" id="exampleSelectBorder" name="kelas">
                        <option value=""></option>
                        <option value="Baik">Baik</option>
                        <option value="Sedang">Sedang</option>
                        <option value="Tidak sehat">Tidak sehat</option>
                      </select>
                    </div>
                </div>
              </div>
              <!-- /.card-body -->

              <div class="card-footer">
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.card -->

          <!-- general form elements -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- footer -->
<?php include './components/footer.php';?>
