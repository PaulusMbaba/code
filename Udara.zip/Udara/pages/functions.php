<?php

/**
 * fungsi naive bayes
 * hanya menerima data uji
 */

 include 'database.php';
// memasukkan data baru
// function newData()
// {
//     $file = fopen('../dataset/data baru.csv', 'r');
//     $lines = [];
//     while (($line = fgetcsv($file)) !== FALSE) {
//         $lines[] = $line;
//     }
//     fclose($file);
//     for($i = 1; $i < count($lines); $i++){
//         masuk_dataset($lines[$i]);
//     }
// }
// newData();
//  membagi dataset 20% uji, 80% latih
function splitDataset()
{
    $datasets = read("SELECT * FROM dataset");
    $lenTest = (int)(count($datasets) * 20 / 100);
    $dataTest = [];
    for($i = 0; $i < $lenTest; $i++){
        $datasets[$i]['co'] = (float)$datasets[$i]['co'];
        $datasets[$i]['co2'] = (float)$datasets[$i]['co2'];
        $datasets[$i]['hc'] = (float)$datasets[$i]['hc'];
        $dataTest[] = $datasets[$i];
    }
    $dataTrain = [];
    for($i = $lenTest; $i < count($datasets); $i++){
        $dataTrain[$i - $lenTest] = $datasets[$i];
    }
    return [$dataTrain,$dataTest];
}

// pelatihan gaussian naivebayes
function pelatihan()
{
    $dataLatih = splitDataset()[0];
    $probKelas = [
        "Baik" => 0,
        "Sedang" => 0,
        "Tidak sehat" => 0
    ];
    /** nilai mean kelas pada atribut
     * indeks 0 : co, 1 : co2, 2 : hc
     */
    $meanKelas = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0]
    ];
    /** jumlah atribut pada kelas
     * indeks 0 : co, 1 : co2, 2 : hc
     */
    $jmlAttr = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0]
    ];
    // menghitung jumlah co, co2, hc masing masing kelas
    foreach($dataLatih as $dl){
        // menghitung jumlah kelas
        $probKelas[$dl['kelas']] += 1;
        // menjumlahkan nilai co,co2,hc
        $meanKelas[$dl['kelas']][0] += $dl['co'];
        $meanKelas[$dl['kelas']][1] += $dl['co2'];
        $meanKelas[$dl['kelas']][2] += $dl['hc'];
        // menghitung jumlah atribut pada kelas
        $jmlAttr[$dl['kelas']][0] += 1;
        $jmlAttr[$dl['kelas']][1] += 1;
        $jmlAttr[$dl['kelas']][2] += 1;
    }
    // menghitung probabilitas masing masing kelas dan mean kelas
    foreach($probKelas as $kelas => $nilai){
        // menghtiung probabilitas kelas
        $probKelas[$kelas] = $probKelas[$kelas] / count($dataLatih);
        // menghitung mean kelas
        $meanKelas[$kelas][0] = $meanKelas[$kelas][0] / $jmlAttr[$kelas][0];
        $meanKelas[$kelas][1] = $meanKelas[$kelas][1] / $jmlAttr[$kelas][1];
        $meanKelas[$kelas][2] = $meanKelas[$kelas][2] / $jmlAttr[$kelas][2];
    }
    // menghtiung standar deviasi
    $standarDeviasi = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0]
    ];
    $sigma = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0]
    ];
    // menghitung sigma data ke-i dikurangi rata-rata
    foreach($dataLatih as $dl){
        $sigma[$dl['kelas']][0] += ($dl['co'] - $meanKelas[$dl['kelas']][0])**2;
        $sigma[$dl['kelas']][1] += ($dl['co2'] - $meanKelas[$dl['kelas']][1])**2;
        $sigma[$dl['kelas']][2] += ($dl['hc'] - $meanKelas[$dl['kelas']][2])**2;
    }
    // menghitung standar deviasi
    foreach($probKelas as $kelas => $nilai){
        $standarDeviasi[$kelas][0] = sqrt($sigma[$kelas][0]/$jmlAttr[$kelas][0]);
        $standarDeviasi[$kelas][1] = sqrt($sigma[$kelas][1]/$jmlAttr[$kelas][1]);
        $standarDeviasi[$kelas][2] = sqrt($sigma[$kelas][2]/$jmlAttr[$kelas][2]);
    }

    // mengambil nilai float hanya dua angka dibelakang koma
    for($i = 0; $i < 3; $i++){
        // mean
        $meanKelas['Baik'][$i] = round($meanKelas['Baik'][$i], 2);
        $meanKelas['Sedang'][$i] = round($meanKelas['Sedang'][$i], 2);
        $meanKelas['Tidak sehat'][$i] = round($meanKelas['Tidak sehat'][$i], 2);

        // standar deviassi
        $standarDeviasi['Baik'][$i] = round($standarDeviasi['Baik'][$i], 2);
        $standarDeviasi['Sedang'][$i] = round($standarDeviasi['Sedang'][$i], 2);
        $standarDeviasi['Tidak sehat'][$i] = round($standarDeviasi['Tidak sehat'][$i], 2);

        // Probabilitas kelas
        $probKelas['Baik'] = round($probKelas['Baik'], 2);
        $probKelas['Sedang'] = round($probKelas['Sedang'], 2);
        $probKelas['Tidak sehat'] = round($probKelas['Tidak sehat'], 2);
    }

    // mengembalikan nilai
    return [$probKelas,$meanKelas,$standarDeviasi];
}

function pengujian()
{
    $dataUji = splitDataset()[1];
    $dataPelatihan = pelatihan();
    $probKelas = $dataPelatihan[0];
    $mean = $dataPelatihan[1];
    $std = $dataPelatihan[2];

    // pengujian
    $gaussian = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0],
    ];
    $gaussians = [];
    $probUji = [
        "Baik" => 0,
        "Sedang" => 0,
        "Tidak sehat" => 0
    ];
    $probuji = [];
    $prediksi = [];
    foreach($dataUji as $du){
        // menghitung nilai gaussian pada kelas baik
        $gaussian['Baik'][0] = gaussian($du['co'], $mean['Baik'][0], $std['Baik'][0]);
        $gaussian['Baik'][1] = gaussian($du['co2'], $mean['Baik'][1], $std['Baik'][1]);
        $gaussian['Baik'][2] = gaussian($du['hc'], $mean['Baik'][2], $std['Baik'][2]);

        // // menghitung nilai gaussian pada kelas sedang
        $gaussian['Sedang'][0] = gaussian($du['co'], $mean['Sedang'][0], $std['Sedang'][0]);
        $gaussian['Sedang'][1] = gaussian($du['co2'], $mean['Sedang'][1], $std['Sedang'][1]);
        $gaussian['Sedang'][2] = gaussian($du['hc'], $mean['Sedang'][2], $std['Sedang'][2]);
        
        // // menghitung nilai gaussian pada kelas tidak sehat
        $gaussian['Tidak sehat'][0] = gaussian($du['co'], $mean['Tidak sehat'][0], $std['Tidak sehat'][0]);
        $gaussian['Tidak sehat'][1] = gaussian($du['co2'], $mean['Tidak sehat'][1], $std['Tidak sehat'][1]);
        $gaussian['Tidak sehat'][2] = gaussian($du['hc'], $mean['Tidak sehat'][2], $std['Tidak sehat'][2]);

        // menghitung probabalitas prediksi kelas
        $probUji['Baik'] = ($gaussian['Baik'][0]*$gaussian['Baik'][1]*$gaussian['Baik'][2]*$probKelas['Baik']);
        $probUji['Sedang'] = ($gaussian['Sedang'][0]*$gaussian['Sedang'][1]*$gaussian['Sedang'][2]*$probKelas['Sedang']);
        $probUji['Tidak sehat'] = ($gaussian['Tidak sehat'][0]*$gaussian['Tidak sehat'][1]*$gaussian['Tidak sehat'][2]*$probKelas['Tidak sehat']);
        // mengambil hasil pengujian
        $gaussians[] = $gaussian;
        $probuji[] = $probUji; 
        $prediksi[] = array_search(max($probUji), $probUji);
    }
    // mengembalikan nilai
    return [$dataUji, $gaussians, $probuji, $prediksi];
}

// confussion matrix
function performa()
{
    $pengujian = pengujian();
    $datauji = $pengujian[0];
    $prediksi = $pengujian[3];
    // menghitung confussion matrix
    $cfMatrix = [
        "Baik" => [0,0,0], //index 0: predik Baik, 1:predik Sedang, 2:predik Tidak sehat
        "Sedang" => [0,0,0], //index 0: predik Baik, 1:predik Sedang, 2:predik Tidak sehat
        "Tidak sehat" => [0,0,0] //index 0: predik Baik, 1:predik Sedang, 2:predik Tidak sehat
    ];
    for($i = 0; $i < count($prediksi); $i++){
        if($prediksi[$i] === 'Baik'){
            $cfMatrix[$datauji[$i]['kelas']][0] += 1;
        }else if($prediksi[$i] === 'Sedang'){
            $cfMatrix[$datauji[$i]['kelas']][1] += 1;
        }else if($prediksi[$i] === 'Tidak sehat'){
            $cfMatrix[$datauji[$i]['kelas']][2] += 1;
        }
    }

    // menghitung akurasi
    $performa = [
        "akurasi" => 0,
        "precision" => 0,
        "recall" => 0
    ];
    // true positif
    $tp = $cfMatrix['Baik'][0] + $cfMatrix['Sedang'][1] + $cfMatrix['Tidak sehat'][2];
    // precision masing masing kelas
    $preB = $cfMatrix['Baik'][0] / ($cfMatrix['Baik'][0] + $cfMatrix['Baik'][1] + $cfMatrix['Baik'][2]);
    $preS = $cfMatrix['Sedang'][1] / ($cfMatrix['Sedang'][0] + $cfMatrix['Sedang'][1] + $cfMatrix['Sedang'][2]);
    $preT = $cfMatrix['Tidak sehat'][2] / ($cfMatrix['Tidak sehat'][0] + $cfMatrix['Tidak sehat'][1] + $cfMatrix['Tidak sehat'][2]);
    // recall masing masing kelas
    $recB = $cfMatrix['Baik'][0] / ($cfMatrix['Baik'][0] + $cfMatrix['Sedang'][0] + $cfMatrix['Tidak sehat'][0]);
    $recS = $cfMatrix['Sedang'][1] / ($cfMatrix['Baik'][1] + $cfMatrix['Sedang'][1] + $cfMatrix['Tidak sehat'][1]);
    $recT = $cfMatrix['Tidak sehat'][2] / ($cfMatrix['Baik'][2] + $cfMatrix['Sedang'][2] + $cfMatrix['Tidak sehat'][2]);

    // menentukan akurasu, precision, recall
    $performa['akurasi'] = $tp / count($prediksi); // True Positif / jumlah data
    $performa['precision'] = ($preB + $preS + $preT) / 3 ; // rata - rata precision
    $performa['recall'] = ($recB + $recS + $recT) / 3 ; // rata - rata recall

    return [$cfMatrix, $performa, count($prediksi)];
}

// prediksi data baru
function predict($newdata)
{
    $dataPelatihan = pelatihan();
    $probKelas = $dataPelatihan[0];
    $mean = $dataPelatihan[1];
    $std = $dataPelatihan[2];
    
    // pengujian
    // menyimpan nilai gaussian
    $gaussian = [
        "Baik" => [0,0,0],
        "Sedang" => [0,0,0],
        "Tidak sehat" => [0,0,0],
    ];
    // menyimpan probabilitas data uji
    $probUji = [
        "Baik" => 0,
        "Sedang" => 0,
        "Tidak sehat" => 0
    ];
    // menghitung nilai gaussian pada kelas baik
    $gaussian['Baik'][0] = gaussian($newdata['co'], $mean['Baik'][0], $std['Baik'][0]);
    $gaussian['Baik'][1] = gaussian($newdata['co2'], $mean['Baik'][1], $std['Baik'][1]);
    $gaussian['Baik'][2] = gaussian($newdata['hc'], $mean['Baik'][2], $std['Baik'][2]);

    // // menghitung nilai gaussian pada kelas sedang
    $gaussian['Sedang'][0] = gaussian($newdata['co'], $mean['Sedang'][0], $std['Sedang'][0]);
    $gaussian['Sedang'][1] = gaussian($newdata['co2'], $mean['Sedang'][1], $std['Sedang'][1]);
    $gaussian['Sedang'][2] = gaussian($newdata['hc'], $mean['Sedang'][2], $std['Sedang'][2]);
    
    // // menghitung nilai gaussian pada kelas tidak sehat
    $gaussian['Tidak sehat'][0] = gaussian($newdata['co'], $mean['Tidak sehat'][0], $std['Tidak sehat'][0]);
    $gaussian['Tidak sehat'][1] = gaussian($newdata['co2'], $mean['Tidak sehat'][1], $std['Tidak sehat'][1]);
    $gaussian['Tidak sehat'][2] = gaussian($newdata['hc'], $mean['Tidak sehat'][2], $std['Tidak sehat'][2]);

    // menghitung probabalitas prediksi kelas
    $probUji['Baik'] = ($gaussian['Baik'][0]*$gaussian['Baik'][1]*$gaussian['Baik'][2]*$probKelas['Baik']);
    $probUji['Sedang'] = ($gaussian['Sedang'][0]*$gaussian['Sedang'][1]*$gaussian['Sedang'][2]*$probKelas['Sedang']);
    $probUji['Tidak sehat'] = ($gaussian['Tidak sehat'][0]*$gaussian['Tidak sehat'][1]*$gaussian['Tidak sehat'][2]*$probKelas['Tidak sehat']);
    
    // mengubah bilangan saintifik menjadi bilangan biasa
    // foreach($gaussian as $kelas=>$nilai){
    //     // data gauss
    //     $gaussian[$kelas][$nilai[0]] = number_format($nilai[0], 2);
    //     $gaussian[$kelas][$nilai[1]] = number_format($nilai[1], 2);
    //     $gaussian[$kelas][$nilai[2]] = number_format($nilai[2], 2);

    //     // data probabilitas
    //     $probUji[$kelas] = number_format($probKelas[$kelas],2);
    // }
    // mengambil hasil prediksi 
    $prediksi = array_search(max($probUji), $probUji);
    
    // mengembalikan nilai
    return [$gaussian, $probUji, $prediksi];
}


/**
 * fungsi gaussian
 */

function gaussian($atr, $mean, $std)
{
    $stdpower = $std**2;
    $atrmeanpower = ($atr-$mean)**2;
    $pembagikiri = $std * sqrt(2*pi());
    $pembagikanan =  2 * $stdpower;
    $hasilkanan = -($atrmeanpower/$pembagikanan);
    $hasilkiri = 1/$pembagikiri;
    $gaussian = $hasilkiri * exp($hasilkanan);
    return $gaussian;
}
?>