<?php
    include 'functions.php';
    $dataPerforma = performa();
    $dataConfussion = $dataPerforma[0];
    $banyakdata = $dataPerforma[2];
    $performa = $dataPerforma[1];
?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>
<!-- main content -->
<div class="content-wrapper">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Performa Naive Bayes</h1>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Metrics</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Metrics</th>
                    <th>Nilai</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $i=0;foreach($performa as $metrics => $nilai):?>
                    <tr>
                      <td><?=$i?></td>
                      <td><?=$metrics?></td>
                      <td><?=$nilai?></td>
                    </tr>
                    <?php $i++;endforeach;?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Confussion Matrix</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Total Data = <?=$banyakdata?></th>
                    <th colspan="3">Prediksi</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Aktual</td>
                      <td>Baik</td>
                      <td>Sedang</td>
                      <td>Tidak sehat</td>
                    </tr>
                    <tr>
                      <td>Baik</td>
                      <td><?=$dataConfussion['Baik'][0]?></td>
                      <td><?=$dataConfussion['Baik'][1]?></td>
                      <td><?=$dataConfussion['Baik'][2]?></td>
                    </tr>
                    <tr>
                      <td>Sedang</td>
                      <td><?=$dataConfussion['Sedang'][0]?></td>
                      <td><?=$dataConfussion['Sedang'][1]?></td>
                      <td><?=$dataConfussion['Sedang'][2]?></td>
                    </tr>
                    <tr>
                      <td>Tidak sehat</td>
                      <td><?=$dataConfussion['Tidak sehat'][0]?></td>
                      <td><?=$dataConfussion['Tidak sehat'][1]?></td>
                      <td><?=$dataConfussion['Tidak sehat'][2]?></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /main content -->
<!-- footer -->
<?php include './components/footer.php';?>