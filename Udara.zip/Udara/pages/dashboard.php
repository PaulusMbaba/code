<?php
include 'database.php';
$dataMonitoring = read("SELECT * FROM monitoring");
date_default_timezone_set('Asia/Ujung_Pandang');
$tgltoday = date('Y-m-d');
$datatoday = read("SELECT * FROM monitoring WHERE tanggal = '$tgltoday'");
?>


  <!-- top -->
  <?php include './components/header.php';?>
  <!-- /top -->

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__wobble" src="../dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <?php include './components/navbar.php';?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include './components/sidebar.php';?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Kualitas Udara <?=date('m-d-Y');?></h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <?php foreach($datatoday as $dt):?>
        <!-- Info boxes -->
        <h4><?=$dt["waktu"]?></h4>
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-vial"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">CO (Karbon Monoksida)</span>
                <span class="info-box-number">
                  <?=$dt['co']?>
                  <small>ppm</small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-vials"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">CO2 (Karbon Dioksida)</span>
                <span class="info-box-number">
                  <?=$dt['co2']?>
                    <small>ppm</small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-atom"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">HC (Hidro Karbon)</span>
                <span class="info-box-number">
                  <?=$dt['hc']?>
                    <small>ppm</small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-microscope"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Kualitas</span>
                <span class="info-box-number"><?=$dt['kualitas']?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
        <?php endforeach;?>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Rekap Hasil Monitoring</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- <div class="card-header">
                <h3 class="card-title">DataTable with minimal features & hover style</h3>
              </div> -->
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>CO</th>
                    <th>CO2</th>
                    <th>HC</th>
                    <th>Kelas</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach($dataMonitoring as $data):?>
                    <tr>
                      <td><?=$data["tanggal"]?></td>
                      <td><?=$data["waktu"]?></td>
                      <td><?=$data["co"]?></td>
                      <td><?=$data["co2"]?></td>
                      <td><?=$data["hc"]?></td>
                      <td><?=$data["kualitas"]?></td>
                    </tr>
                  <?php endforeach;?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <!-- footer -->
  <?php include './components/footer.php';?>
