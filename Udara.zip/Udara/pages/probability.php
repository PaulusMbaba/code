<?php
include 'functions.php';
$dataPelatihan = pelatihan();
$listKelas = array_keys($dataPelatihan[0]);
$mean = $dataPelatihan[1];
$std = $dataPelatihan[2];

?>
<!-- top header -->
<?php include './components/header.php';?>
<!-- navbar -->
<?php include './components/navbar.php';?>
<!-- preload -->
<!-- sidebar -->
<?php include './components/sidebar.php';?>
<!-- main content -->
<div class="content-wrapper">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Pelatihan Naive Bayes</h1>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Probabilitas Kelas</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                    <table class="table table-sm">
                    <thead>
                        <tr>
                        <th>Kelas</th>
                        <th>Nilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($dataPelatihan[0] as $kelas => $nilai):?>
                        <tr>
                            <td><?=$kelas?></td>
                            <td><?=$nilai?></td>
                        </tr>
                        <?php endforeach;?>
                    </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Atribut CO</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                    <table class="table table-sm">
                    <thead>
                        <tr>
                        <th>Kelas</th>
                        <th>Mean</th>
                        <th>Standar Deviasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 0; $i < count($listKelas); $i++):?>
                        <tr>
                            <td><?=$listKelas[$i]?></td>
                            <td><?=$mean[$listKelas[$i]][0]?></td>
                            <td><?=$std[$listKelas[$i]][0]?></td>
                        </tr>
                        <?php endfor;?>
                    </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Atribut CO2</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                    <table class="table table-sm">
                    <thead>
                        <tr>
                        <th>Kelas</th>
                        <th>Mean</th>
                        <th>Standar Deviasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 0; $i < count($listKelas); $i++):?>
                        <tr>
                            <td><?=$listKelas[$i]?></td>
                            <td><?=$mean[$listKelas[$i]][1]?></td>
                            <td><?=$std[$listKelas[$i]][2]?></td>
                        </tr>
                        <?php endfor;?>
                    </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Atribut HC</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                    <table class="table table-sm">
                    <thead>
                        <tr>
                        <th>Kelas</th>
                        <th>Mean</th>
                        <th>Standar Deviasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 0; $i < count($listKelas); $i++):?>
                        <tr>
                            <td><?=$listKelas[$i]?></td>
                            <td><?=$mean[$listKelas[$i]][2]?></td>
                            <td><?=$std[$listKelas[$i]][2]?></td>
                        </tr>
                        <?php endfor;?>
                    </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /main content -->
<!-- footer -->
<?php include './components/footer.php';?>