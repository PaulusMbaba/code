<?php

// koneksi database
$db_host = 'localhost';
$db_name = 'db_udara';
$db_user = 'root';
$db_pass = '';

$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// hanya untuk sekali masukkan data
function masuk_dataset($data)
{
    global $koneksi;
    $co = $data[0];
    $co2 = $data[1];
    $hc = $data[2];
    $kelas = $data[3];
    $query = "INSERT INTO dataset VALUES('','$co','$co2','$hc','$kelas')";
    mysqli_query($koneksi,$query);
}

function create($data)
{
    global $koneksi;
    $waktu = $data["waktu"];
    $tanggal = date('Y-m-d',strtotime($data["tgl"]));
    $co = $data["co"];
    $co2 = $data["co2"];
    $hc = $data["hc"];
    $kelas = $data["kelas"];
    $query = "INSERT INTO monitoring VALUES('','$waktu','$tanggal','$co','$co2','$hc','$kelas')";
    mysqli_query($koneksi, $query);
}

// mengambil seluruh data dari database
function read($query)
{
    global $koneksi;
    $result = mysqli_query($koneksi, $query);
    $data = [];
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    return $data;
}

// menambah datasets
function addDataset($data)
{
    global $koneksi;
    $co = $data['co'];
    $co2 = $data['co2'];
    $hc = $data['hc'];
    $kelas = $data['kelas'];

    $query = "INSERT INTO dataset VALUES('','$co','$co2','$hc','$kelas')";
    mysqli_query($koneksi, $query);
    if(mysqli_affected_rows($koneksi) > 0){
        echo "
        <script>
            alert('Data Berhasil Ditambahkan!');
            document.location.href = 'tambahData.php';
        </script>
        ";
    }else{
        echo "
        <script>
            alert('Data Gagal Ditambahkan!');
            document.location.href = 'tambahData.php';
        </script>
        ";
    }
}
